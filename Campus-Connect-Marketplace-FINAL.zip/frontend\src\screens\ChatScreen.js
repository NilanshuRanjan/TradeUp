import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TextInput, 
  TouchableOpacity, 
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import apiClient from '../services/api';
import { validateMessageContent, sanitizeString } from '../utils/validation';

const ChatScreen = ({ route, navigation }) => {
  const { conversationId, listingTitle, otherUserId } = route.params;
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [messageText, setMessageText] = useState('');
  const [currentUserId, setCurrentUserId] = useState(null);
  const flatListRef = useRef(null);

  useEffect(() => {
    // Set screen title to listing title if provided
    if (listingTitle) {
      navigation.setOptions({ title: listingTitle });
    }

    // Get current user ID from token (simplified approach)
    getCurrentUserId();
    fetchMessages();
  }, [conversationId, listingTitle]);

  const getCurrentUserId = async () => {
    try {
      const userId = await apiClient.tokenManager.getCurrentUserId();
      if (userId) {
        setCurrentUserId(userId);
      } else {
        // Fallback: extract from conversation ID if token method fails
        const parts = conversationId.split('_');
        if (parts.length === 3) {
          const [, userId1, userId2] = parts;
          // Determine which user is the current user (not the otherUserId)
          const currentId = userId1 === otherUserId ? userId2 : userId1;
          setCurrentUserId(currentId);
        }
      }
    } catch (error) {
      console.error('Error getting current user ID:', error);
      // Fallback: extract from conversation ID
      const parts = conversationId.split('_');
      if (parts.length === 3) {
        const [, userId1, userId2] = parts;
        const currentId = userId1 === otherUserId ? userId2 : userId1;
        setCurrentUserId(currentId);
      }
    }
  };

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await apiClient.messages.getConversation(conversationId);
      
      if (response.data.success) {
        setMessages(response.data.data);
        // Scroll to bottom after messages load
        setTimeout(() => {
          scrollToBottom();
        }, 100);
      } else {
        Alert.alert('Error', 'Failed to load conversation');
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
      Alert.alert(
        'Error',
        error.isNetworkError 
          ? 'Network error. Please check your connection.' 
          : 'Failed to load conversation. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    // Validate message content
    const sanitizedMessage = sanitizeString(messageText);
    const validationError = validateMessageContent(sanitizedMessage);
    
    if (validationError) {
      Alert.alert('Invalid Message', validationError);
      return;
    }

    const tempMessage = {
      _id: Date.now().toString(), // Temporary ID
      content: sanitizedMessage,
      sender: { _id: currentUserId, username: 'You' },
      receiver: { _id: otherUserId },
      createdAt: new Date().toISOString(),
      isTemporary: true
    };

    try {
      setSending(true);
      
      // Optimistically add message to UI
      setMessages(prevMessages => [...prevMessages, tempMessage]);
      setMessageText('');
      scrollToBottom();

      // Parse conversation ID to get listing and receiver info
      const parts = conversationId.split('_');
      const [listingId] = parts;

      const messageData = {
        listingId,
        receiverId: otherUserId,
        content: sanitizedMessage
      };

      const response = await apiClient.messages.send(messageData);
      
      if (response.data.success) {
        // Replace temporary message with real message from server
        setMessages(prevMessages => 
          prevMessages.map(msg => 
            msg._id === tempMessage._id ? response.data.data : msg
          )
        );
      } else {
        // Remove temporary message on failure
        setMessages(prevMessages => 
          prevMessages.filter(msg => msg._id !== tempMessage._id)
        );
        Alert.alert('Error', 'Failed to send message. Please try again.');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Remove temporary message on error
      setMessages(prevMessages => 
        prevMessages.filter(msg => msg._id !== tempMessage._id)
      );
      
      Alert.alert(
        'Error',
        error.isNetworkError 
          ? 'Network error. Please check your connection.' 
          : 'Failed to send message. Please try again.'
      );
    } finally {
      setSending(false);
    }
  };

  const scrollToBottom = () => {
    if (flatListRef.current && messages.length > 0) {
      flatListRef.current.scrollToEnd({ animated: true });
    }
  };

  const formatTimestamp = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      // Show time for messages from today
      return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } else {
      // Show date for older messages
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    }
  };

  const renderMessage = ({ item }) => {
    const isCurrentUser = item.sender._id === currentUserId;
    const isTemporary = item.isTemporary;

    return (
      <View style={[
        styles.messageContainer,
        isCurrentUser ? styles.currentUserMessage : styles.otherUserMessage
      ]}>
        <View style={[
          styles.messageBubble,
          isCurrentUser ? styles.currentUserBubble : styles.otherUserBubble,
          isTemporary && styles.temporaryMessage
        ]}>
          <Text style={[
            styles.messageText,
            isCurrentUser ? styles.currentUserText : styles.otherUserText
          ]}>
            {item.content}
          </Text>
          <Text style={[
            styles.timestamp,
            isCurrentUser ? styles.currentUserTimestamp : styles.otherUserTimestamp
          ]}>
            {formatTimestamp(item.createdAt)}
          </Text>
        </View>
      </View>
    );
  };

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>No messages yet</Text>
      <Text style={styles.emptySubtext}>Start the conversation!</Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2E7D32" />
        <Text style={styles.loadingText}>Loading conversation...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item._id}
        style={styles.messagesList}
        contentContainerStyle={messages.length === 0 ? styles.emptyListContainer : styles.messagesContainer}
        ListEmptyComponent={renderEmptyState}
        onContentSizeChange={scrollToBottom}
        onLayout={scrollToBottom}
      />
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={messageText}
          onChangeText={(text) => setMessageText(sanitizeString(text))}
          placeholder="Type a message..."
          multiline
          maxLength={1000}
          editable={!sending}
        />
        <TouchableOpacity
          style={[
            styles.sendButton,
            (!messageText.trim() || sending) && styles.sendButtonDisabled
          ]}
          onPress={sendMessage}
          disabled={!messageText.trim() || sending}
        >
          {sending ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text style={styles.sendButtonText}>Send</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  messagesList: {
    flex: 1,
  },
  messagesContainer: {
    padding: 16,
    paddingBottom: 8,
  },
  emptyListContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
  },
  messageContainer: {
    marginVertical: 4,
  },
  currentUserMessage: {
    alignItems: 'flex-end',
  },
  otherUserMessage: {
    alignItems: 'flex-start',
  },
  messageBubble: {
    maxWidth: '80%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  currentUserBubble: {
    backgroundColor: '#2E7D32',
    borderBottomRightRadius: 4,
  },
  otherUserBubble: {
    backgroundColor: '#fff',
    borderBottomLeftRadius: 4,
  },
  temporaryMessage: {
    opacity: 0.7,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
    marginBottom: 4,
  },
  currentUserText: {
    color: '#fff',
  },
  otherUserText: {
    color: '#333',
  },
  timestamp: {
    fontSize: 12,
    alignSelf: 'flex-end',
  },
  currentUserTimestamp: {
    color: 'rgba(255, 255, 255, 0.8)',
  },
  otherUserTimestamp: {
    color: '#999',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#fff',
    alignItems: 'flex-end',
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    maxHeight: 100,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  sendButton: {
    backgroundColor: '#2E7D32',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 60,
  },
  sendButtonDisabled: {
    backgroundColor: '#a5d6a7',
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default ChatScreen;