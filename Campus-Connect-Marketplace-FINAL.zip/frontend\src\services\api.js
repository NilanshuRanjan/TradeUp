import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createRetryHandler } from '../utils/errorHandler';

// Base API configuration - Use your computer's IP address for mobile testing
// For development: Replace 'localhost' with your computer's IP address
// For production: Use your deployed server URL
const API_BASE_URL = __DEV__ 
  ? 'http://192.168.1.4:3000/api'  // Your computer's IP address
  : 'https://your-production-server.com/api';

const ACCESS_TOKEN_KEY = 'accessToken';
const REFRESH_TOKEN_KEY = 'refreshToken';
const TOKEN_EXPIRY_KEY = 'tokenExpiry';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Token management utilities
const tokenManager = {
  // Store token pair with expiration time
  async setTokens(accessToken, refreshToken, expiresIn) {
    try {
      // Calculate expiry time based on expiresIn (e.g., "15m")
      let expiryTime;
      if (typeof expiresIn === 'string') {
        // Parse time strings like "15m", "1h", "7d"
        const timeValue = parseInt(expiresIn);
        const timeUnit = expiresIn.slice(-1);
        let multiplier = 1;
        
        switch (timeUnit) {
          case 's': multiplier = 1000; break;
          case 'm': multiplier = 60 * 1000; break;
          case 'h': multiplier = 60 * 60 * 1000; break;
          case 'd': multiplier = 24 * 60 * 60 * 1000; break;
          default: multiplier = 60 * 1000; // Default to minutes
        }
        
        expiryTime = Date.now() + (timeValue * multiplier);
      } else {
        // Fallback: decode JWT to get expiration
        const payload = JSON.parse(atob(accessToken.split('.')[1]));
        expiryTime = payload.exp * 1000; // Convert to milliseconds
      }
      
      await AsyncStorage.multiSet([
        [ACCESS_TOKEN_KEY, accessToken],
        [REFRESH_TOKEN_KEY, refreshToken],
        [TOKEN_EXPIRY_KEY, expiryTime.toString()]
      ]);
      
      return true;
    } catch (error) {
      console.error('Error storing tokens:', error);
      return false;
    }
  },

  // Get access token if it's still valid
  async getValidAccessToken() {
    try {
      const [[, accessToken], [, expiryStr]] = await AsyncStorage.multiGet([
        ACCESS_TOKEN_KEY,
        TOKEN_EXPIRY_KEY
      ]);

      if (!accessToken || !expiryStr) {
        return null;
      }

      const expiry = parseInt(expiryStr, 10);
      const now = Date.now();
      
      // Check if token is expired (with 2 minute buffer)
      if (now >= expiry - 120000) {
        return null; // Token is expired or about to expire
      }

      return accessToken;
    } catch (error) {
      console.error('Error getting access token:', error);
      return null;
    }
  },

  // Get refresh token
  async getRefreshToken() {
    try {
      const refreshToken = await AsyncStorage.getItem(REFRESH_TOKEN_KEY);
      return refreshToken;
    } catch (error) {
      console.error('Error getting refresh token:', error);
      return null;
    }
  },

  // Refresh access token using refresh token
  async refreshAccessToken() {
    try {
      const refreshToken = await this.getRefreshToken();
      if (!refreshToken) {
        throw new Error('No refresh token available');
      }

      const response = await api.post('/auth/refresh', { refreshToken });
      
      if (response.data.success && response.data.data) {
        const { accessToken, refreshToken: newRefreshToken, expiresIn } = response.data.data;
        await this.setTokens(accessToken, newRefreshToken, expiresIn);
        return accessToken;
      }
      
      throw new Error('Token refresh failed');
    } catch (error) {
      console.error('Error refreshing token:', error);
      await this.clearTokens();
      throw error;
    }
  },

  // Get current user ID from token
  async getCurrentUserId() {
    try {
      const token = await this.getValidAccessToken();
      if (!token) return null;

      // Decode JWT payload (basic decode without verification)
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.userId || payload.id || payload.sub;
    } catch (error) {
      console.error('Error getting user ID from token:', error);
      return null;
    }
  },

  // Clear stored tokens
  async clearTokens() {
    try {
      await AsyncStorage.multiRemove([ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY, TOKEN_EXPIRY_KEY]);
      return true;
    } catch (error) {
      console.error('Error clearing tokens:', error);
      return false;
    }
  },

  // Check if user is authenticated
  async isAuthenticated() {
    const accessToken = await this.getValidAccessToken();
    if (accessToken) {
      return true;
    }
    
    // Try to refresh token if access token is expired
    try {
      const newAccessToken = await this.refreshAccessToken();
      return !!newAccessToken;
    } catch (error) {
      return false;
    }
  }
};

// Request interceptor to add auth token
api.interceptors.request.use(
  async (config) => {
    try {
      let token = await tokenManager.getValidAccessToken();
      
      // If no valid access token, try to refresh
      if (!token) {
        try {
          token = await tokenManager.refreshAccessToken();
        } catch (error) {
          // Refresh failed, user needs to log in again
          console.log('Token refresh failed, user needs to log in again');
        }
      }
      
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.error('Error attaching auth token:', error);
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors and token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Handle authentication errors
    if (error.response?.status === 401) {
      // Prevent infinite retry loops
      if (!originalRequest._retry) {
        originalRequest._retry = true;
        
        try {
          // Try to refresh the token
          const newToken = await tokenManager.refreshAccessToken();
          
          if (newToken) {
            // Retry the original request with new token
            originalRequest.headers.Authorization = `Bearer ${newToken}`;
            return api(originalRequest);
          }
        } catch (refreshError) {
          // Refresh failed, clear tokens and require re-login
          await tokenManager.clearTokens();
          return Promise.reject({
            ...error,
            isAuthError: true,
            message: 'Authentication required. Please log in again.'
          });
        }
      }
      
      // If retry already attempted or refresh failed, clear tokens
      await tokenManager.clearTokens();
      return Promise.reject({
        ...error,
        isAuthError: true,
        message: 'Authentication required. Please log in again.'
      });
    }

    // Handle other HTTP errors with enhanced error information
    if (error.response) {
      // Server responded with error status
      const enhancedError = {
        ...error,
        message: error.response.data?.error || error.response.data?.message || error.message,
        statusCode: error.response.status,
        isNetworkError: false
      };
      return Promise.reject(enhancedError);
    } else if (error.request) {
      // Network error - no response received
      return Promise.reject({
        ...error,
        message: 'Network error. Please check your connection.',
        isNetworkError: true,
        code: 'NETWORK_ERROR'
      });
    } else if (error.code === 'ECONNABORTED') {
      // Request timeout
      return Promise.reject({
        ...error,
        message: 'Request timed out. Please try again.',
        isNetworkError: true,
        code: 'TIMEOUT_ERROR'
      });
    }

    return Promise.reject(error);
  }
);

// Enhanced API client with authentication methods
const apiClient = {
  // Core axios instance
  instance: api,

  // Authentication methods
  auth: {
    async login(credentials) {
      const response = await api.post('/auth/login', credentials);
      if (response.data.success && response.data.data) {
        const { accessToken, refreshToken, expiresIn } = response.data.data;
        await tokenManager.setTokens(accessToken, refreshToken, expiresIn);
      }
      return response;
    },

    async register(userData) {
      const response = await api.post('/auth/register', userData);
      if (response.data.success && response.data.data) {
        const { accessToken, refreshToken, expiresIn } = response.data.data;
        await tokenManager.setTokens(accessToken, refreshToken, expiresIn);
      }
      return response;
    },

    async logout() {
      await tokenManager.clearTokens();
      return true;
    },

    async isAuthenticated() {
      return await tokenManager.isAuthenticated();
    },

    async refreshToken() {
      try {
        const newToken = await tokenManager.refreshAccessToken();
        return !!newToken;
      } catch (error) {
        return false;
      }
    }
  },

  // Listing methods
  listings: {
    async getAll() {
      const retryableGetAll = createRetryHandler(() => api.get('/listings'));
      return await retryableGetAll();
    },

    async getMy() {
      const retryableGetMy = createRetryHandler(() => api.get('/listings/my'));
      return await retryableGetMy();
    },

    async getById(id) {
      const retryableGetById = createRetryHandler(() => api.get(`/listings/${id}`));
      return await retryableGetById();
    },

    async create(listingData) {
      return await api.post('/listings', listingData);
    },

    async markAsSold(id) {
      return await api.put(`/listings/${id}/sold`);
    }
  },

  // Message methods
  messages: {
    async getConversation(conversationId) {
      const retryableGetConversation = createRetryHandler(() => api.get(`/messages/${conversationId}`));
      return await retryableGetConversation();
    },

    async send(messageData) {
      return await api.post('/messages', messageData);
    }
  },

  // Token management utilities (exposed for testing)
  tokenManager
};

export default apiClient;