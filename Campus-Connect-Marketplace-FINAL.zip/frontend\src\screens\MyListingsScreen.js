import React, { useState, useCallback } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  RefreshControl,
  Alert 
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import apiClient from '../services/api';

const MyListingsScreen = ({ navigation }) => {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchMyListings = async (isRefresh = false) => {
    try {
      if (!isRefresh) setLoading(true);
      
      const response = await apiClient.listings.getMy();
      
      if (response.data.success) {
        setListings(response.data.data || []);
      } else {
        Alert.alert('Error', 'Failed to load your listings');
      }
    } catch (error) {
      console.error('Error fetching my listings:', error);
      Alert.alert(
        'Error', 
        error.isNetworkError 
          ? 'Network error. Please check your connection.' 
          : 'Failed to load your listings. Please try again.'
      );
    } finally {
      setLoading(false);
      if (isRefresh) setRefreshing(false);
    }
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchMyListings(true);
  }, []);

  // Fetch listings when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      fetchMyListings();
    }, [])
  );

  const handleMarkAsSold = async (listingId) => {
    Alert.alert(
      'Mark as Sold',
      'Are you sure you want to mark this listing as sold?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Mark as Sold',
          style: 'destructive',
          onPress: async () => {
            try {
              const response = await apiClient.listings.markAsSold(listingId);
              
              if (response.data.success) {
                // Update the listing in the local state
                setListings(prevListings => 
                  prevListings.map(listing => 
                    listing._id === listingId 
                      ? { ...listing, isSold: true }
                      : listing
                  )
                );
                Alert.alert('Success', 'Listing marked as sold!');
              } else {
                Alert.alert('Error', response.data.error || 'Failed to mark listing as sold');
              }
            } catch (error) {
              console.error('Error marking listing as sold:', error);
              Alert.alert('Error', 'Failed to mark listing as sold. Please try again.');
            }
          },
        },
      ]
    );
  };

  const renderListingItem = ({ item }) => (
    <View style={styles.listingCard}>
      <View style={styles.listingHeader}>
        <Text style={styles.listingTitle} numberOfLines={1}>
          {item.title}
        </Text>
        <View style={[
          styles.statusBadge,
          item.isSold ? styles.soldBadge : styles.activeBadge
        ]}>
          <Text style={[
            styles.statusText,
            item.isSold ? styles.soldText : styles.activeText
          ]}>
            {item.isSold ? 'SOLD' : 'ACTIVE'}
          </Text>
        </View>
      </View>
      
      <Text style={styles.listingDescription} numberOfLines={2}>
        {item.description}
      </Text>
      
      <View style={styles.listingFooter}>
        <View style={styles.priceContainer}>
          <Text style={styles.price}>${item.price.toFixed(2)}</Text>
          <Text style={styles.category}>{item.category}</Text>
        </View>
        
        {!item.isSold && (
          <TouchableOpacity
            style={styles.markSoldButton}
            onPress={() => handleMarkAsSold(item._id)}
            testID={`mark-sold-${item._id}`}
          >
            <Text style={styles.markSoldButtonText}>Mark as Sold</Text>
          </TouchableOpacity>
        )}
      </View>
      
      <Text style={styles.createdDate}>
        Created: {new Date(item.createdAt).toLocaleDateString()}
      </Text>
    </View>
  );

  const renderEmptyState = () => (
    <View style={styles.emptyState}>
      <Text style={styles.emptyTitle}>No listings yet</Text>
      <Text style={styles.emptySubtitle}>
        Create your first listing to start selling!
      </Text>
      <TouchableOpacity 
        style={styles.createButton}
        onPress={() => navigation.navigate('CreateListing')}
        testID="create-first-listing-button"
      >
        <Text style={styles.createButtonText}>Create Listing</Text>
      </TouchableOpacity>
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <Text style={styles.headerTitle}>My Listings</Text>
      <TouchableOpacity 
        style={styles.createHeaderButton}
        onPress={() => navigation.navigate('CreateListing')}
        testID="create-listing-header-button"
      >
        <Text style={styles.createHeaderButtonText}>+ Create New</Text>
      </TouchableOpacity>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.container}>
        {renderHeader()}
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading your listings...</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {renderHeader()}
      <FlatList
        data={listings}
        renderItem={renderListingItem}
        keyExtractor={(item) => item._id}
        contentContainerStyle={listings.length === 0 ? styles.emptyContainer : styles.listContainer}
        ListEmptyComponent={renderEmptyState}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#1976D2']}
            tintColor="#1976D2"
          />
        }
        showsVerticalScrollIndicator={false}
        testID="my-listings-flatlist"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  createHeaderButton: {
    backgroundColor: '#1976D2',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 6,
  },
  createHeaderButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  listContainer: {
    paddingVertical: 8,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyState: {
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  createButton: {
    backgroundColor: '#1976D2',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  createButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
  },
  listingCard: {
    backgroundColor: '#fff',
    marginHorizontal: 16,
    marginVertical: 8,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  listingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  listingTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 12,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    minWidth: 60,
    alignItems: 'center',
  },
  activeBadge: {
    backgroundColor: '#E8F5E8',
  },
  soldBadge: {
    backgroundColor: '#FFF3E0',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  activeText: {
    color: '#2E7D32',
  },
  soldText: {
    color: '#F57C00',
  },
  listingDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
    lineHeight: 20,
  },
  listingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  priceContainer: {
    flex: 1,
  },
  price: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 2,
  },
  category: {
    fontSize: 12,
    color: '#999',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  markSoldButton: {
    backgroundColor: '#FF5722',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  markSoldButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  createdDate: {
    fontSize: 12,
    color: '#999',
    textAlign: 'right',
  },
});

export default MyListingsScreen;