import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  Alert, 
  KeyboardAvoidingView, 
  ScrollView,
  Platform 
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import FormInput from '../components/FormInput';
import apiClient from '../services/api';
import { 
  validateListingTitle, 
  validateListingDescription, 
  validatePrice, 
  validateCategory,
  sanitizeFormData
} from '../utils/validation';

const CATEGORIES = [
  { label: 'Select a category', value: '' },
  { label: 'Textbooks', value: 'Textbooks' },
  { label: 'Furniture', value: 'Furniture' },
  { label: 'Electronics', value: 'Electronics' },
  { label: 'Clothing', value: 'Clothing' },
  { label: 'Other', value: 'Other' },
];

const CreateListingScreen = () => {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const validateForm = () => {
    const newErrors = {};

    // Title validation
    const titleError = validateListingTitle(formData.title);
    if (titleError) {
      newErrors.title = titleError;
    }

    // Description validation
    const descriptionError = validateListingDescription(formData.description);
    if (descriptionError) {
      newErrors.description = descriptionError;
    }

    // Price validation
    const priceError = validatePrice(formData.price);
    if (priceError) {
      newErrors.price = priceError;
    }

    // Category validation
    const categoryError = validateCategory(formData.category);
    if (categoryError) {
      newErrors.category = categoryError;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field, value) => {
    // Sanitize input
    const sanitizedValue = typeof value === 'string' ? value.replace(/<[^>]*>/g, '').trim() : value;
    
    setFormData(prev => ({
      ...prev,
      [field]: sanitizedValue
    }));
    
    // Real-time validation
    if (field === 'title') {
      const error = validateListingTitle(sanitizedValue);
      setErrors(prev => ({ ...prev, title: error }));
    } else if (field === 'description') {
      const error = validateListingDescription(sanitizedValue);
      setErrors(prev => ({ ...prev, description: error }));
    } else if (field === 'price') {
      const error = validatePrice(sanitizedValue);
      setErrors(prev => ({ ...prev, price: error }));
    } else if (field === 'category') {
      const error = validateCategory(sanitizedValue);
      setErrors(prev => ({ ...prev, category: error }));
    }
  };

  const handleCreateListing = async () => {
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      // Sanitize form data before sending
      const sanitizedData = sanitizeFormData({
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price),
        category: formData.category,
      });

      const response = await apiClient.listings.create(sanitizedData);
      
      if (response.data.success) {
        Alert.alert(
          'Success', 
          'Your listing has been created successfully!',
          [
            {
              text: 'OK',
              onPress: () => navigation.goBack()
            }
          ]
        );
      } else {
        Alert.alert('Error', response.data.error || 'Failed to create listing');
      }
    } catch (error) {
      console.error('Create listing error:', error);
      const errorMessage = error.message || 'Failed to create listing. Please try again.';
      Alert.alert('Error', errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView 
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Text style={styles.title}>Create New Listing</Text>
          <Text style={styles.subtitle}>Share what you're selling with the campus community</Text>
        </View>

        <View style={styles.form}>
          <FormInput
            label="Title"
            value={formData.title}
            onChangeText={(value) => handleInputChange('title', value)}
            placeholder="What are you selling?"
            error={errors.title}
            required
            testID="create-listing-title-input"
            maxLength={100}
          />

          <FormInput
            label="Description"
            value={formData.description}
            onChangeText={(value) => handleInputChange('description', value)}
            placeholder="Describe your item in detail..."
            error={errors.description}
            required
            testID="create-listing-description-input"
            multiline
            numberOfLines={4}
            maxLength={500}
            style={styles.textArea}
          />

          <FormInput
            label="Price"
            value={formData.price}
            onChangeText={(value) => handleInputChange('price', value)}
            placeholder="0.00"
            keyboardType="numeric"
            error={errors.price}
            required
            testID="create-listing-price-input"
          />

          <View style={styles.pickerContainer}>
            <Text style={styles.pickerLabel}>
              Category
              <Text style={styles.required}> *</Text>
            </Text>
            <View style={[
              styles.pickerWrapper,
              errors.category && styles.pickerError
            ]}>
              <Picker
                selectedValue={formData.category}
                onValueChange={(value) => handleInputChange('category', value)}
                style={styles.picker}
                testID="create-listing-category-picker"
              >
                {CATEGORIES.map((category) => (
                  <Picker.Item
                    key={category.value}
                    label={category.label}
                    value={category.value}
                  />
                ))}
              </Picker>
            </View>
            {errors.category && (
              <Text 
                style={styles.errorText}
                testID="create-listing-category-error"
              >
                {errors.category}
              </Text>
            )}
          </View>

          <TouchableOpacity
            style={[styles.createButton, isLoading && styles.buttonDisabled]}
            onPress={handleCreateListing}
            disabled={isLoading}
            testID="create-listing-submit-button"
          >
            <Text style={styles.createButtonText}>
              {isLoading ? 'Creating Listing...' : 'Create Listing'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingVertical: 32,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  form: {
    flex: 1,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  pickerContainer: {
    marginBottom: 16,
  },
  pickerLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  required: {
    color: '#FF3B30',
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    backgroundColor: '#FFF',
  },
  pickerError: {
    borderColor: '#FF3B30',
    backgroundColor: '#FFF5F5',
  },
  picker: {
    height: 48,
  },
  errorText: {
    fontSize: 14,
    color: '#FF3B30',
    marginTop: 4,
    marginLeft: 4,
  },
  createButton: {
    backgroundColor: '#007AFF',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  buttonDisabled: {
    backgroundColor: '#B0B0B0',
  },
  createButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default CreateListingScreen;