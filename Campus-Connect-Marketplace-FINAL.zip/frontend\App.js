import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AuthLoadingScreen from './src/screens/AuthLoadingScreen';
import LoginScreen from './src/screens/LoginScreen';
import SignUpScreen from './src/screens/SignUpScreen';
import HomeScreen from './src/screens/HomeScreen';
import ListingDetailScreen from './src/screens/ListingDetailScreen';
import CreateListingScreen from './src/screens/CreateListingScreen';
import MyListingsScreen from './src/screens/MyListingsScreen';
import ChatScreen from './src/screens/ChatScreen';
import ErrorBoundary from './src/components/ErrorBoundary';
import NetworkStatus from './src/components/NetworkStatus';

const AuthStack = createStackNavigator();
const MainStack = createStackNavigator();
const RootStack = createStackNavigator();

// Authentication Stack - for non-authenticated users
const AuthStackScreen = () => (
  <AuthStack.Navigator>
    <AuthStack.Screen 
      name="Login" 
      component={LoginScreen}
      options={{ title: 'Login' }}
    />
    <AuthStack.Screen 
      name="SignUp" 
      component={SignUpScreen}
      options={{ title: 'Sign Up' }}
    />
  </AuthStack.Navigator>
);

// Main Stack - for authenticated users
const MainStackScreen = () => (
  <MainStack.Navigator>
    <MainStack.Screen 
      name="Home" 
      component={HomeScreen}
      options={{ title: 'Campus Connect' }}
    />
    <MainStack.Screen 
      name="ListingDetail" 
      component={ListingDetailScreen}
      options={{ title: 'Listing Details' }}
    />
    <MainStack.Screen 
      name="CreateListing" 
      component={CreateListingScreen}
      options={{ title: 'Create Listing' }}
    />
    <MainStack.Screen 
      name="MyListings" 
      component={MyListingsScreen}
      options={{ title: 'My Listings' }}
    />
    <MainStack.Screen 
      name="Chat" 
      component={ChatScreen}
      options={{ title: 'Chat' }}
    />
  </MainStack.Navigator>
);

// Root Stack - handles initial loading and stack switching
const App = () => {
  return (
    <ErrorBoundary>
      <NavigationContainer>
        <NetworkStatus />
        <RootStack.Navigator 
          initialRouteName="AuthLoading"
          screenOptions={{ headerShown: false }}
        >
          <RootStack.Screen 
            name="AuthLoading" 
            component={AuthLoadingScreen}
          />
          <RootStack.Screen 
            name="Auth" 
            component={AuthStackScreen}
          />
          <RootStack.Screen 
            name="Main" 
            component={MainStackScreen}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    </ErrorBoundary>
  );
};

export default App;