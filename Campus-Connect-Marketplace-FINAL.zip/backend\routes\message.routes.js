const express = require('express');
const Message = require('../models/message.model');
const Listing = require('../models/listing.model');
const authMiddleware = require('../middleware/auth.middleware');
const { asyncHandler, AppError } = require('../middleware/error.middleware');
const { validateMessageCreation, validateConversationId } = require('../middleware/validation.middleware');
const router = express.Router();

// GET /api/messages/:conversationId - Fetch conversation history (protected)
router.get('/:conversationId', authMiddleware, validateConversationId, asyncHandler(async (req, res) => {
  const { conversationId } = req.params;

  // Parse conversation ID to verify user is part of the conversation
  const parts = conversationId.split('_');
  const [listingId, userId1, userId2] = parts;
  
  if (req.userId !== userId1 && req.userId !== userId2) {
    throw new AppError('Access denied. You are not part of this conversation.', 403);
  }

  // Fetch messages in chronological order
  const messages = await Message.find({ conversationId })
    .populate('sender', 'username')
    .populate('receiver', 'username')
    .sort({ createdAt: 1 }); // Oldest first for chat history

  res.status(200).json({
    success: true,
    data: messages,
    message: 'Conversation history retrieved successfully'
  });
}));

// POST /api/messages - Send new message (protected)
router.post('/', authMiddleware, validateMessageCreation, asyncHandler(async (req, res) => {
  const { listingId, receiverId, content } = req.body;

  // Verify listing exists
  const listing = await Listing.findById(listingId);
  if (!listing) {
    throw new AppError('Listing not found', 404);
  }

  // Prevent users from messaging themselves
  if (req.userId === receiverId) {
    throw new AppError('Cannot send message to yourself', 400);
  }

  // Generate conversation ID
  const conversationId = Message.generateConversationId(listingId, req.userId, receiverId);

  // Create new message
  const message = new Message({
    conversationId,
    sender: req.userId,
    receiver: receiverId,
    content
  });

  await message.save();

  // Populate sender and receiver info for response
  await message.populate('sender', 'username');
  await message.populate('receiver', 'username');

  res.status(201).json({
    success: true,
    data: message,
    message: 'Message sent successfully'
  });
}));

module.exports = router;